
public class Food {

	String foodname,foodloc;
	int foodprice;
	public Food(String fn,String fl,int fp)
	{
		this.foodname = fn;
		this.foodloc=fl;
		this.foodprice = fp;
	}
}
